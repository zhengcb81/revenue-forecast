from pathlib import Path
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import time

root = Path(__file__).resolve().parent
repo = Path(r'C:\Users\郑曾波\Projects\revenue-forecast')
author = Path(r'C:\Users\郑曾波\Projects\revenue-forecast-du5-units')
label = sys.argv[1]
assert label.replace('-', '').isalnum()
assert not (root / (label + '.json')).exists()
owned = Path(tempfile.mkdtemp(prefix='owned-pytest-', dir=root))
env = dict(os.environ)
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['REVENUE_PUBLICATION_REGISTRY'] = str(owned / 'registry.jsonl')
guard = [repo/'artifacts/registry/publications.jsonl', author/'artifacts/registry/publications.jsonl']
guard += [repo/'assurance/runs'/name for name in ['daily_alert.jsonl','weekly_alert.jsonl','weekly_manifest.json']]
guard += [author/path for path in ['scripts/research/input_quantities.py','scripts/analysis/sensitivity.py','tests/test_du5_money_unit_registry.py','docs/plans/du5-units-2026-10-15/e2e/run_e2e.py']]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
before = {str(p):sha(p) for p in guard}
argv = [sys.executable,'-B','-X','utf8','-m','pytest','-q','-p','no:cacheprovider',*sys.argv[2:],'--basetemp',str(owned/'pytest')]
start = time.monotonic()
record = {'argv':argv,'guard_before':before}
try:
    proc = subprocess.run(argv, cwd=repo, env=env, capture_output=True, timeout=180)
    (root/(label+'.stdout')).write_bytes(proc.stdout)
    (root/(label+'.stderr')).write_bytes(proc.stderr)
    record['exit_code'] = proc.returncode
    print(proc.stdout.decode('utf-8', errors='replace')[-6500:])
    print(proc.stderr.decode('utf-8', errors='replace')[-1000:])
finally:
    record['elapsed_seconds'] = time.monotonic() - start
    record['guard_after'] = {str(p):sha(p) for p in guard}
    record['guard_unchanged'] = record['guard_after'] == before
    assert owned.resolve().parent == root.resolve() and owned.name.startswith('owned-pytest-')
    for path in owned.rglob('*'):
        if path.is_file(): path.chmod(stat.S_IREAD | stat.S_IWRITE)
    shutil.rmtree(owned)
    record['owned_temp_removed'] = not owned.exists()
    (root/(label+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert record['guard_unchanged']
