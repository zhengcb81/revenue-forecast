from pathlib import Path
import hashlib

repo = Path(r'C:\Users\郑曾波\Projects\revenue-forecast')
path = repo / 'scripts/research/input_quantities.py'
text = path.read_text(encoding='utf-8')
assert hashlib.sha256(path.read_bytes()).hexdigest() == '5ce354c2b99c2f0466db9f91f27d95bdb8f9989006950d04f3ad84e29943ecfd'
text=text.replace('from contracts.evidence import finite_number, require', 'from contracts.evidence import ForecastInputError, finite_number, require')
old='''    description = _UNIT_DESCRIPTIONS[_normalize_unit(engine_unit, f"{field}.engine_unit")]
    family = description["family"]'''
new='''    canonical_engine_unit = _normalize_unit(engine_unit, f"{field}.engine_unit")
    description = _UNIT_DESCRIPTIONS[canonical_engine_unit]
    family = description["family"]'''
assert text.count(old)==1
text=text.replace(old,new)
old='''            f"(pp/percent/bp/ratio), got {engine_unit}",
        )
    elif shock_type == "absolute":'''
new='''            f"(pp/percent/bp/ratio), got {engine_unit}",
        )
        require(
            canonical_engine_unit == _ENGINE_UNIT_BY_SHOCK[shock_type],
            f"{field}: engine unit {engine_unit} does not match the numeric "
            f"contract unit {_ENGINE_UNIT_BY_SHOCK[shock_type]} for {shock_type}",
        )
    elif shock_type == "absolute":'''
assert text.count(old)==1
text=text.replace(old,new)
old='''            f"{parameter_id} (dimension {dimension})",
        )
    return expected'''
new='''            f"{parameter_id} (dimension {dimension})",
        )
        try:
            parameter_unit = _normalize_unit(
                parameter.get("unit"), f"{field}.parameter.unit"
            )
        except ForecastInputError as exc:
            raise ForecastInputError(
                f"{field}: parameter {parameter_id} unit "
                f"{parameter.get('unit')!r} cannot be safely interpreted as a "
                f"registered count unit"
            ) from exc
        parameter_description = _UNIT_DESCRIPTIONS[parameter_unit]
        require(
            parameter_description["family"] == "count",
            f"{field}: parameter {parameter_id} unit {parameter.get('unit')!r} "
            f"is not a count unit; dimension alone does not establish its scale",
        )
        require(
            description["scale"] == parameter_description["scale"],
            f"{field}: record unit {engine_unit} scale does not match parameter "
            f"{parameter_id} unit {parameter.get('unit')!r}; convert to the "
            f"parameter unit at construction",
        )
    return expected'''
assert text.count(old)==1
text=text.replace(old,new)
path.write_text(text, encoding='utf-8', newline='\n')
test=repo/'tests/test_du5_root_unit_boundaries.py'
test.write_text(test.read_text(encoding='utf-8').replace('import sys\n',''),encoding='utf-8',newline='\n')
print('Updated shared unit helper; sensitivity consumer unchanged')
