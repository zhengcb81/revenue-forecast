# DU5-RF-UNITS 独立接收审查

状态：**REQUIRES_ROOT_FIX**。两项共用单位责任层缺口已通过实际 `run_forecast(mode='draft')` 复现；不应仅凭作者集中回归通过并线。

被审作者树 `C:/Users/郑曾波/Projects/revenue-forecast-du5-units`；基线 `090a63109a62507a23adcaa774cf65021e7c4614`。正常宿主只读 Git 确认 clean，25 个改动路径。沙箱 Git 的“非工作树”是假环境错误；作者 CodeGraph 未初始化，未执行 init，改读交接明确列出的实际文件。作者源码、测试、PWF、Git 未改。

## P1-01：share family 相同不能证明数字遵守具体 shock_type 的数值单位

位置：`scripts/research/input_quantities.py:344` 的 `validate_input_quantity_for_parameter` 只要求 `family == 'share'`。consumer 随后允许 `basis_point` 与 `percentage_point`/`percent` 使用不同的数字合同。

实际复现：

- 正控：builder `5 pp -> ratio=0.05`，`percentage_point`，参数0.8实际请求0.75/0.85。
- 仅把同一测试的 `shock_type` 改为 `basis_point`，自洽原记录未改，真实 draft 仍接受，却请求0.799995/0.800005，少了10000倍。
- 反向：`5 bp -> basis_point=5` 记录被改为 `percentage_point` 仍接受，请求-4.2/5.8，发生夹紧。夹紧不能纠正单位错误。
- `5 bp` identity 记录与 `shock_type='percent', shock_value=5` 组合仍接受，对121收入参数施加500%相对冲击，终值786.5。

根因修复方向：从单一 shock 合同推导应有的 engine unit；`basis_point` 必须使用 basis_point 数值，`percentage_point` 和 `percent` 必须使用 ratio 数值。在现有共享 helper 内验证，不增加别处币种/身份门。不禁止合法的 pp/bp 经 builder 真实转换到正确目标单位。

## P1-02：count 只验证 dimension，百万个与个仍可静默混用

位置：`scripts/research/input_quantities.py:400` 的 count 分支只检查 dimension，未检查真实 parameter.unit。

实际复现采用原生 volume 合成模型，所有 quantity 参数及对应 exact-value claim 单位一致改为 `units` 或 `million units`，保持原来的来源/公式，不借用旧夹具中错误的自由文本 `USD million` 标签：

- 正控：参数100 units，5 units冲击，真实终值上210/下190。
- 同一 units 参数配5 million_units identity记录仍通过，结果仍210/190，金额只计算5个而非500万个。
- 反向：参数100 million units配5 units identity记录仍通过，同样按5百万个施加，错100万倍。
- 正控：builder明确 `5 million_units -> units=5,000,000` 后，真实上终值10,000,200，转换确实进入算术。

根因修复方向：同一有限单位描述解析 count parameter.unit 并绑定 engine_unit 的数量尺度；不能通过把所有count当一个family而推断尺度。无法解释的、实际带record的目标单位应明确诊断，不能更改没有record的旧预测公式，也不能猜测吨、面积或复合分母。

## 已通过的有限检查

- 12 个实际 draft 探针：7符合期望，5个不该接受的输入被接受，归结为上述两类根因。
- 对当前主仓旧 `input_quantities.py`（SHA见 JSON）运行129组既有share/USD/RMB/count转换，零/正/负数生成字典全部与交付逐字相同，未发现生成记录兼容漂移。
- HKD正确币种正控通过；USD记录配HKD参数、千元record配百万参数、金额record配money-per-unit参数均正确拒绝。
- 没有全仓测试、联网、LLM、正式发布、安装或production文件写入。本次探针在 import 前设置隔离 registry；均使用 draft，隔离 registry 本身也未创建。

## Registry 事件复核

- 作者树 `artifacts/registry/publications.jsonl` 当前缺席，`artifacts` 也缺席。
- 已存证 archive `registry-incident-removed.jsonl`：9202 bytes、12行，SHA256 `0a1e2cdc52e647351a542ea0e32af43b0b03d750d534e5bf66455e77572878c8` 与作者披露完全相符；逐行 canonical hash、prev chain 验证通过。
- 只能证明归档内容自洽及当前缺席；**不能独立追溯证明事件前不存在，也不能仅凭摘要SHA证明12行均对应宣称的原始合成输入**。没有据此扩大删除任何主仓registry。
- 作者 E2E 驱动当前在首次 formal 调用前重定向当前进程与子进程环境；源码实际在127行 import runtime、145行才设置env，因此“before import”这一披露不准确。目前 registry_file 动态读取环境，未见该import导致写入；建议ROOT整理时把隔离提前，不能把该非致命顺序差异等同于当前仍污染。
- 本次独立探针前后作者默认registry均缺席，主仓默认registry SHA均为 `bc3256bbc7abca8c0ae28155a614237f50860bd914578a3d48d4f74ab62d1e91`，未改变。本次 owned TEMP 已删除。

## 复现与限制

在 ROOT 执行：`python -B -X utf8 .planning/shared-reading-production/du5-reception/rf-review/probe.py`。

`probe-results.json` 保存最终12组实测；进程exit0表示诊断脚本执行/保存完成，**不表示12组均通过**，其中5组 `pass=false`。`probe-results-initial.json` 为最初10组结果；`probe-results-count-fixture-rejected.json` 保存随后第一次units夹具因旧asset fact单位校验未同步而被拒绝的无效计数试验，这一中间结果不作count缺陷证明。最终探针已同步该模型全部quantity参数，合法/真实转换正控通过后才确认count边界。

被审四份源码/测试哈希及执行前后相同证据在 `probe-results.json`。ROOT修复后应以新的文件名/收据复跑，保留本次失败证据。组件/合成单测结果不认证任何真实公司收入数字或买方经济质量。
