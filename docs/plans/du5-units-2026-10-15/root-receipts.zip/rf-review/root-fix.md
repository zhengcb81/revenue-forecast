# DU5-RF-UNITS ROOT 接收修复

状态：**ROOT_FIX_TESTED_PENDING_INTEGRATION**。原独审 `review.md/json` 的失败证据保留，本文件记录接收侧修复，不篡改作者交接。

## 改动

- `C:/Users/郑曾波/Projects/revenue-forecast/scripts/research/input_quantities.py`：在同一共享 helper 中复用 `_ENGINE_UNIT_BY_SHOCK`，按真实 shock_type 核对规范化 engine unit；复用 `_UNIT_DESCRIPTIONS` 核对 count 记录与真实 parameter.unit 的数量尺度。未知/复合目标在有转换记录时给明确诊断；不增权限、身份校验、原文解析、FX 或第二单位表。
- 新 `C:/Users/郑曾波/Projects/revenue-forecast/tests/test_du5_root_unit_boundaries.py`：22 条新边界/正控，全部实际走 draft sensitivity。同步合成模型 quantity 参数/声明，保留独立手算期望，覆盖正向/反向count转换、相对/绝对数值合同、未知/复合单位及没有转换record的旧行为。
- 现有 `scripts/analysis/sensitivity.py` 接收作者的单一helper调用即足够，ROOT没有再改它。没有修改任何旧测试 expected、作者树、alert WIP、Git index 或安装副本。

## TDD 与集中验收

- `root-red.json/stdout/stderr`：11 FAILED /11 PASSED，11个失败均为该拒绝的边界没有拒绝，不是缺API或夹具异常。
- `root-green-concentrated.json/stdout/stderr`：一次集中 ROOT新边界＋作者单位＋旧单位＋sensitivity DAG＋input semantics＋W07/W08原生矩阵，**210 PASSED /9 SKIPPED /59 subtests PASSED，28.95s**，真实pytest exit0。
- `root-legacy-129.json`：从准确Git基线090a6310只读提取旧模块，对129组旧USD/RMB/share/count零/正/负转换逐字典比较，并将旧记录送入当前重推导验证，全部相等/通过。既有生成记录没有被改写。
- Ruff两个实际改动文件：All checks passed。
- 所有pytest子进程在import前设置明确registry、owned TEMP和无bytecode；运行后作者四份源码/测试、RF三个现存alert/manifest和两仓默认registry SHA不变，owned TEMP已删除。

最终精确SHA、命令、退出码与保护项见 `root-fix.json`。原registry事件的历史无法独立证明部分仍按原审查报告保留。未stage/commit/push、未安装/联网、没有供应商调用。ROOT下一步为最终整合检查与正常发布，不需要为本有限修复另设小节点人工签收。

## C节点完整公开入口 E2E

ROOT额外授权窄幅修改 `docs/plans/du5-units-2026-10-15/e2e/run_e2e.py`：新增 `--receipt-dir ABS_PATH`，旧默认保留；进程registry设置提前到任何runtime import之前，结束恢复原进程env。未改作者历史23项检查及期望。

真实命令见 `../rf-cli-final/receipt.json` 的 argv，明确运行主目录driver并将receipt-dir设为ROOT新目录。exit0，**23/23检查通过，4.7184371秒**；完整CLI validate-only/formal输出/Markdown、进程内formal、HKD手算终值和旧USD/CNY正控均实跑，0API。主仓/作者默认registry、三个alert/manifest、两仓历史PWF/receipts和作者源码SHA全部未变。driver内部Temp与外层owned Temp均已清理，sentinel保持，无残留子输出。新driver SHA：`78af5cbe85e1d2ec2a8b250e63093f55c015a1ddbcbb29b456e2f2667a9c836d`。未重跑210集中、未stage/commit/push。
