from pathlib import Path
import hashlib

path=Path(r'C:\Users\郑曾波\Projects\revenue-forecast\docs\plans\du5-units-2026-10-15\e2e\run_e2e.py')
assert hashlib.sha256(path.read_bytes()).hexdigest()=='826f9a934494fc9d6ccf58205cb8c13ff16ad5d2f2b474ea1676136a050eb78d'
text=path.read_text(encoding='utf-8')
text=text.replace('import copy\n','import argparse\nimport copy\n',1)
text=text.replace('    python docs/plans/du5-units-2026-10-15/e2e/run_e2e.py\n','    python docs/plans/du5-units-2026-10-15/e2e/run_e2e.py\n    python docs/plans/du5-units-2026-10-15/e2e/run_e2e.py --receipt-dir ABS_PATH\n',1)
old='''def main() -> int:
    if "--build-fixture" in sys.argv:
        build_fixture()
        return 0'''
new='''def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-fixture", action="store_true")
    parser.add_argument("--receipt-dir", type=Path, default=RECEIPTS,
                        help="receipt output directory (default: retained lane receipts)")
    args = parser.parse_args()
    receipt_dir = args.receipt_dir.resolve()
    if args.build_fixture:
        build_fixture()
        return 0'''
assert text.count(old)==1
text=text.replace(old,new)
imports='''    from revenue_core import ForecastInputError, run_forecast
    from research.input_quantities import (
        convert_input_quantity,
        validate_input_quantity_record,
    )
    from revenue_report import validate_published_forecast

'''
assert text.count(imports)==1
text=text.replace(imports,'')
text=text.replace('''    os.environ["REVENUE_PUBLICATION_REGISTRY"] = str(registry)''','''    previous_registry = os.environ.get("REVENUE_PUBLICATION_REGISTRY")
    os.environ["REVENUE_PUBLICATION_REGISTRY"] = str(registry)''',1)
text=text.replace('''    try:
        # --- 1. hand-computed unit oracles''','''    try:
'''+''.join('    '+line+'\n' if line else '\n' for line in imports.splitlines())+'''        # --- 1. hand-computed unit oracles''',1)
text=text.replace('''        write_json(RECEIPTS / "e2e-cleanup.json", cleanup)''','''        if previous_registry is None:
            os.environ.pop("REVENUE_PUBLICATION_REGISTRY", None)
        else:
            os.environ["REVENUE_PUBLICATION_REGISTRY"] = previous_registry
        write_json(receipt_dir / "e2e-cleanup.json", cleanup)''',1)
text=text.replace('''        RECEIPTS / "e2e-run.json",''','''        receipt_dir / "e2e-run.json",''',1)
path.write_text(text,encoding='utf-8',newline='\n')
print(hashlib.sha256(path.read_bytes()).hexdigest())
