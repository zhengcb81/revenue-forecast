from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time

AUTHOR = Path(r'C:\Users\郑曾波\Projects\revenue-forecast-du5-units')
ROOT = Path(__file__).resolve().parent
CANONICAL = AUTHOR.parent / 'revenue-forecast'
OWNED = Path(tempfile.mkdtemp(prefix='owned-probe-', dir=ROOT))
os.environ['REVENUE_PUBLICATION_REGISTRY'] = str(OWNED / 'publications.jsonl')
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
sys.dont_write_bytecode = True
sys.path[:0] = [str(AUTHOR / 'scripts'), str(AUTHOR / 'tests')]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None

sources = ['scripts/research/input_quantities.py','scripts/analysis/sensitivity.py','tests/test_du5_money_unit_registry.py','docs/plans/du5-units-2026-10-15/e2e/run_e2e.py']
before = {p:sha(AUTHOR/p) for p in sources}
defaults = [AUTHOR/'artifacts/registry/publications.jsonl',CANONICAL/'artifacts/registry/publications.jsonl']
default_before = {str(p):sha(p) for p in defaults}
result = {'source_sha256':before,'groups':[], 'registry_before':default_before}
start = time.monotonic()
try:
    from revenue_core import run_forecast, canonical_sha256
    from research.input_quantities import build_sensitivity_test, convert_input_quantity, validate_input_quantity_for_parameter
    from test_golden_behavior_lock import model_document
    from test_recognition_bridge import forecast_document

    def run(name, factory, test_factory, expected_reject):
        data = factory()
        test = test_factory(data)
        data['sensitivity_tests'] = [test]
        row = {'name':name,'expected_reject':expected_reject,'input_test':test}
        parameter = next(p for p in data['parameters'] if p['parameter_id']==test['parameter_id'])
        row['parameter'] = {k:parameter.get(k) for k in ['parameter_id','dimension','unit','currency','scale','value']}
        try:
            output = run_forecast(copy.deepcopy(data), mode='draft')
            s = output['sensitivities'][0]
            row.update(accepted=True,actual={k:s.get(k) for k in ['shock_type','shock_value','requested_values','clamped','up_terminal_revenue','down_terminal_revenue']})
        except Exception as exc:
            row.update(accepted=False,error_type=type(exc).__name__,message=str(exc))
        row['pass']=row['accepted'] != expected_reject
        result['groups'].append(row)

    def ratio_test(shock_type=None):
        def build(_):
            t=build_sensitivity_test(parameter_id='capacity_utilization_base_2026',value=5,input_unit='pp',shock_semantics='additive')
            if shock_type: t['shock_type']=shock_type
            return t
        return build
    run('ratio_additive_positive',lambda:model_document('capacity'),ratio_test(),False)
    run('ratio_record_relabelled_basis_point',lambda:model_document('capacity'),ratio_test('basis_point'),True)
    def bp_bad(_):
        t=build_sensitivity_test(parameter_id='capacity_utilization_base_2026',value=5,input_unit='bp',shock_semantics='additive')
        t['shock_type']='percentage_point'
        return t
    run('basis_point_record_relabelled_percentage_point',lambda:model_document('capacity'),bp_bad,True)
    def relative_bad(_):
        r=convert_input_quantity(5,input_unit='bp',engine_unit='basis_point')
        return {'name':'bad_relative','parameter_id':'0_base_2027','shock_type':'percent','shock_value':5,'input_quantity':r}
    run('basis_point_record_relabelled_relative_percent',forecast_document,relative_bad,True)

    def count_test(unit):
        return lambda _:build_sensitivity_test(parameter_id='volume_saleable_volume_base_2027',value=5,input_unit=unit,shock_semantics='absolute')
    def count_document(unit):
        data=model_document('volume')
        pid='volume_saleable_volume_base_2027'
        selected=[p for p in data['parameters'] if p['dimension']=='quantity']
        ids={p['parameter_id'] for p in selected}
        for parameter in selected:parameter['unit']=unit
        for c in data['evidence_claims']:
            if c.get('target_id') in ids and 'unit' in c:c['unit']=unit
        return data
    run('count_plain_units_positive',lambda:count_document('units'),count_test('units'),False)
    run('count_million_record_on_plain_parameter',lambda:count_document('units'),count_test('million_units'),True)
    run('count_units_record_on_million_parameter',lambda:count_document('million units'),count_test('units'),True)
    run('count_converted_units_positive',lambda:count_document('units'),lambda _:build_sensitivity_test(parameter_id='volume_saleable_volume_base_2027',value=5,input_unit='million_units',engine_unit='units',shock_semantics='absolute'),False)

    def hkd():
        data=forecast_document()
        data['currency']='HKD'
        for p in data['parameters']:
            if 'currency' in p:
                p['currency']='HKD';p['unit']='HKD million'
        for c in data['evidence_claims']:
            if isinstance(c.get('unit'),str) and c['unit'].startswith('USD '):c['unit']='HKD '+c['unit'][4:]
        return data
    def money_test(unit):
        return lambda _:build_sensitivity_test(parameter_id='0_base_2027',value=5,input_unit=unit,shock_semantics='absolute')
    run('hkd_money_positive',hkd,money_test('hkd_million'),False)
    run('usd_record_on_hkd_rejected',hkd,money_test('usd_million'),True)
    run('thousand_record_on_million_rejected',hkd,money_test('hkd_thousand'),True)
    run('money_on_per_unit_rejected',lambda:model_document('volume'),lambda _:build_sensitivity_test(parameter_id='volume_realized_price_base_2026',value=5,input_unit='usd_million',shock_semantics='absolute'),True)

    spec=importlib.util.spec_from_file_location('root_legacy_quantities',CANONICAL/'scripts/research/input_quantities.py')
    legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
    units=['pp','percent','ratio','basis_point','usd_million','usd_thousand','usd_billion','rmb_million','rmb_billion','rmb_100m','units','thousand_units','million_units']
    compared=0;diffs=[]
    for left in units:
        for right in units:
            for value in [0,2.5,-5]:
                try:old=legacy.convert_input_quantity(value,input_unit=left,engine_unit=right)
                except ValueError:continue
                new=convert_input_quantity(value,input_unit=left,engine_unit=right)
                compared+=1
                if old!=new:diffs.append({'source':left,'target':right,'value':value})
    result['legacy_comparison']={'compared':compared,'differences':diffs,'canonical_source_sha256':sha(CANONICAL/'scripts/research/input_quantities.py')}
    archive=AUTHOR/'docs/plans/du5-units-2026-10-15/receipts/registry-incident-removed.jsonl'
    rows=[json.loads(line) for line in archive.read_text(encoding='utf-8').splitlines() if line.strip()]
    prior=None;chain=True
    for row in rows:
        chain=chain and row['prev_line_sha256']==prior and row['line_sha256']==canonical_sha256({k:v for k,v in row.items() if k!='line_sha256'})
        prior=row['line_sha256']
    result['incident']={'archive_sha256':sha(archive),'bytes':archive.stat().st_size,'entry_count':len(rows),'chain_valid':chain,'historical_absence_independently_proven':False}
finally:
    result['source_unchanged']={p:sha(AUTHOR/p)==digest for p,digest in before.items()}
    result['registry_after']={str(p):sha(p) for p in defaults}
    result['default_registry_unchanged']=result['registry_after']==default_before
    result['owned_registry_created']=(OWNED/'publications.jsonl').exists()
    resolved=OWNED.resolve()
    assert resolved.parent==ROOT.resolve() and resolved.name.startswith('owned-probe-')
    shutil.rmtree(resolved)
    result['owned_temp_removed']=not resolved.exists()
    result['elapsed_seconds']=time.monotonic()-start
    (ROOT/'probe-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(result['groups']),'unexpected':sum(not x['pass'] for x in result['groups']),'legacy':result.get('legacy_comparison'),'cleanup':result['owned_temp_removed'],'default_registry_unchanged':result['default_registry_unchanged']},ensure_ascii=False))
