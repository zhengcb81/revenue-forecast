from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import types

root=Path(__file__).resolve().parent
repo=Path(r'C:\Users\郑曾波\Projects\revenue-forecast')
owned=Path(tempfile.mkdtemp(prefix='owned-legacy-',dir=root))
os.environ['REVENUE_PUBLICATION_REGISTRY']=str(owned/'registry.jsonl')
sys.dont_write_bytecode=True
sys.path.insert(0,str(repo/'scripts'))
record={}
try:
    proc=subprocess.run(['git','-c','core.optionalLocks=false','show','090a63109a62507a23adcaa774cf65021e7c4614:scripts/research/input_quantities.py'],cwd=repo,capture_output=True,check=True,timeout=15)
    legacy=types.ModuleType('root_du5_frozen_baseline')
    exec(compile(proc.stdout,'git:090a6310/input_quantities.py','exec'),legacy.__dict__)
    from research.input_quantities import convert_input_quantity, validate_input_quantity_record
    units=['pp','percent','ratio','basis_point','usd_million','usd_thousand','usd_billion','rmb_million','rmb_billion','rmb_100m','units','thousand_units','million_units']
    cases=[]
    for left in units:
        for right in units:
            for value in [0,2.5,-5]:
                try:old=legacy.convert_input_quantity(value,input_unit=left,engine_unit=right)
                except ValueError:continue
                new=convert_input_quantity(value,input_unit=left,engine_unit=right)
                reread=validate_input_quantity_record(old,field='legacy')
                cases.append({'source':left,'target':right,'value':value,'record':old,'exact_dict_equal':new==old,'old_record_valid':reread==old})
    record={'base_commit':'090a63109a62507a23adcaa774cf65021e7c4614','baseline_blob_sha256':hashlib.sha256(proc.stdout).hexdigest(),'compared':len(cases),'all_equal':all(c['exact_dict_equal'] and c['old_record_valid'] for c in cases),'cases':cases}
finally:
    assert owned.resolve().parent==root.resolve() and owned.name.startswith('owned-legacy-')
    assert not (owned/'registry.jsonl').exists()
    shutil.rmtree(owned)
    record['owned_temp_removed']=not owned.exists()
    (root/'root-legacy-129.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert record['all_equal'] and record['compared']==129
print('129 exact dictionaries and stored legacy record rederivations passed')
