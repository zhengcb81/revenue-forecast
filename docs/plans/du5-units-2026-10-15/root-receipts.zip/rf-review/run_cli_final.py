from pathlib import Path
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import time

review=Path(__file__).resolve().parent
out=review.parent/'rf-cli-final'
assert not out.exists(), out
out.mkdir()
repo=Path(r'C:\Users\郑曾波\Projects\revenue-forecast')
author=repo.parent/'revenue-forecast-du5-units'
driver=repo/'docs/plans/du5-units-2026-10-15/e2e/run_e2e.py'
owned=Path(tempfile.mkdtemp(prefix='owned-cli-',dir=out))
env=dict(os.environ)
env['REVENUE_PUBLICATION_REGISTRY']=str(owned/'outer-registry.jsonl')
env['PYTHONDONTWRITEBYTECODE']='1'
env['TEMP']=str(owned)
env['TMP']=str(owned)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
guard=[repo/'artifacts/registry/publications.jsonl',author/'artifacts/registry/publications.jsonl']
guard += [repo/'assurance/runs'/name for name in ['daily_alert.jsonl','weekly_alert.jsonl','weekly_manifest.json']]
guard += list((repo/'docs/plans/du5-units-2026-10-15/receipts').rglob('*'))
guard += list((author/'docs/plans/du5-units-2026-10-15').rglob('*'))
guard += [author/p for p in ['scripts/research/input_quantities.py','scripts/analysis/sensitivity.py','tests/test_du5_money_unit_registry.py']]
guard=[p for p in guard if not p.exists() or p.is_file()]
before={str(p):sha(p) for p in guard}
argv=[sys.executable,'-B','-X','utf8',str(driver),'--receipt-dir',str(out)]
receipt={'argv':argv,'cwd':str(repo),'driver_sha256':sha(driver),'guard_before':before,'supplier_calls':0}
start=time.monotonic()
try:
    proc=subprocess.run(argv,cwd=repo,env=env,capture_output=True,timeout=180)
    (out/'stdout.txt').write_bytes(proc.stdout)
    (out/'stderr.txt').write_bytes(proc.stderr)
    receipt['exit_code']=proc.returncode
    print(proc.stdout.decode('utf-8',errors='replace'))
    print(proc.stderr.decode('utf-8',errors='replace'))
    receipt['e2e']=json.loads((out/'e2e-run.json').read_text(encoding='utf-8'))
    receipt['cleanup']=json.loads((out/'e2e-cleanup.json').read_text(encoding='utf-8'))
finally:
    receipt['elapsed_seconds']=time.monotonic()-start
    receipt['guard_after']={str(p):sha(p) for p in guard}
    receipt['guard_unchanged']=receipt['guard_after']==before
    receipt['outer_registry_absent']=not (owned/'outer-registry.jsonl').exists()
    receipt['inner_temps_left']=[p.name for p in owned.iterdir()]
    assert owned.resolve().parent==out.resolve() and owned.name.startswith('owned-cli-')
    for p in owned.rglob('*'):
        if p.is_file(): p.chmod(stat.S_IREAD|stat.S_IWRITE)
    shutil.rmtree(owned)
    receipt['outer_temp_removed']=not owned.exists()
    (out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert receipt['exit_code']==0 and receipt['guard_unchanged']
assert receipt['outer_registry_absent'] and not receipt['inner_temps_left']
assert not receipt['e2e']['failures']
print(json.dumps({'exit_code':receipt['exit_code'],'checks':len(receipt['e2e']['checks']),'guard_unchanged':receipt['guard_unchanged'],'elapsed':receipt['elapsed_seconds'],'driver_sha256':receipt['driver_sha256']},ensure_ascii=False))
