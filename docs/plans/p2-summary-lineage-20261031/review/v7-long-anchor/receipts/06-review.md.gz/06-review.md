# Independent RF long-anchor contract review — PASS

Final six-file scope against baseline `85054d7b260a3805b43ce6a4d49d44579745a015`. No blocking or unresolved defect found.

Independently executed final verification: **81 domain tests + 29 adversarial probes = 110 passed**. Logs: [domain](final-domain-tests.log), [independent probes](final-independent-probes.log). Both final launches omit PYTHONPATH.

The original/manual path still enforces 10–500 characters and does not import the optional summary owner. Adopted long anchors retain the existing 128-KiB complete-proof bound, exact source/span/locator checks, complete support/context, research reason and used-parameter/formula closure. A fake or empty field does not pass.

Independent checks covered long grouped originals; null/empty/fake proof; quote editing plus rehash; locator/source/formula/backlink tampering; missing or erased context; legacy 9/10/500/501; adopted minimum 9/10; exact 131072/131073-byte proof boundaries with ASCII and UTF-8; and publication/report/snapshot preservation with a future/negative qualifier. The CI/pre-push command selects the new regression exactly once.

Fixed R4 input: 804624 bytes, raw SHA-256 `22e23a23b0827b969ec30a23c8910608127e06f86de1fde9554996d5ff34d1cc`. All eight cards passed native validation without input mutation. The original 519-character card remains 1473 UTF-8 bytes; complete proof 22645 bytes. RF native canonical JSON SHA is `e3bab3a68034f1d7002ab55078a9588d76bf17c0421cde7d8fd937944a6925af`; a tool-envelope hash is a distinct identity.

Final seals (LF means CRLF normalized to LF; no other transformation):

| File | Raw SHA-256 | LF SHA-256 |
|---|---|---|
| `scripts/contracts/document.py` | `575506fe0a4a3021a578c39c3a4c9faf9cd76e8336b4e1349b1b1330a4e40fb4` | `014cbd8e9ad1d84e4e460187a57f566a1f05900911a2087bf1ac5df5d2c1a9dc` |
| `scripts/narrative_summary_provenance.py` | `478b02d128bd1dfb3cfed491562b8b6c3bcf82e2b5e4d4f400993cbd6b9f5633` | `c3711e12272ba72ac1a99585abff1d311b0144b407c6517a3f9b4536c9aa046e` |
| `references/input-construction.md` | `d7c5e87b3cf1ad26389f74bee5e2757f3462b82a773b7859af7fb536254e87e6` | `d2aca6d4f70b31f2dcf5ef48d659e72a6b33d852b68acbd074d5ebad1c8c1b77` |
| `tests/test_summary_long_excerpt.py` | `e8b1f3fba26483628d3ee223c75d434f938a06659260c3081d10ce202b48afa8` | `e8b1f3fba26483628d3ee223c75d434f938a06659260c3081d10ce202b48afa8` |
| `tools/pre_push_gate.py` | `462e15a5856493c4001528046ecf3986501c43dc997375ce86289e34355403f3` | `2e57120ff7b9ea29fef6d427b6cea8bfe34a1cf917070d501f5f172f58928063` |
| `tests/test_ci_smoke_plan.py` | `58cf1b57c10c9c49051e91b6c7c975bb5d1a24d1e5498a91a3f76a1f9827a784` | `f91a3e51236922bb23632a343024dd993cadcf5cbc4dd5005db80f07d0583ae0` |

Before/after final seals match for all six files and the four preexisting assurance/runs WIP files. Product code, author input, execution packages, Git index, catalogs and configuration were not written by this reviewer. The owned .m9 temp tree was checked to resolve under CWP, checked for reparse points and removed; both exact sandbox-relocated ephemeral paths are absent. See [cleanup](cleanup.json).

Actual inspected files and sections, detailed checks, evidence hashes and unsigned scope are enumerated in [review.json](review.json). Exact tracked diff: [final-reviewed.diff](final-reviewed.diff). The new untracked regression is bound by its final seal.

This PASS signs the evidence-contract repair only. It does not sign company economics, semantic research quality, a fresh external-source authentication, deployment or a full remote CI run. The partial frozen DTO retains its existing local-consistency boundary. Remaining short-excerpt checks apply to other classic, target and actual-value paths.
