"""Independent no-network contract probes. Synthetic fixtures are not company research."""
from copy import deepcopy
import builtins
import importlib.util
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

import pytest

RF = Path('C:/Users/郑曾波/Projects/revenue-forecast')
OUTPUT = Path(__file__).resolve().parent
REAL_INPUT = Path('C:/Users/郑曾波/Projects/revenue-forecast-audit/runs/r1-20261021-cn-wuxi-apptec/execution_replays/r1-remediation-04/forecast/summary-linked-v1/input.json')
sys.path[:0] = [str(RF / 'scripts'), str(RF / 'tests')]

from company_wiki_narrative_contracts import validate_narrative_response
from contracts.evidence import Collector, canonical_sha256, text_sha256
from fix_hashes import apply_hash_fixes
from narrative_summary_provenance import MAX_BYTES
from revenue_backtest import create_snapshot, validate_snapshot
from revenue_core import run_forecast, validate_document
from revenue_report import _escape, render_markdown, validate_published_forecast
from test_du11_narrative_citation_wire import descriptor, wire
from test_narrative_summary_usage import PARAMETER, choose, consume
from test_recognition_bridge import forecast_document


def forbidden(*args, **kwargs):
    raise AssertionError('independent review forbids network, source rereads and child processes')


@pytest.fixture(autouse=True)
def isolated(monkeypatch, tmp_path):
    monkeypatch.setenv('REVENUE_PUBLICATION_REGISTRY', str(tmp_path / 'registry.jsonl'))
    monkeypatch.delenv('REVENUE_ATTESTATION_PROVIDER', raising=False)
    monkeypatch.setattr(socket, 'create_connection', forbidden)
    monkeypatch.setattr(socket.socket, 'connect', forbidden)
    monkeypatch.setattr(subprocess, 'Popen', forbidden)
    monkeypatch.setattr('source_narrative_context.read_narrative_context', forbidden)


def adopted(quote=None):
    # Rebuild the source bytes and source identity, not just the claim hash.
    desc = descriptor()
    quote = quote or ('[CEO] ' + '海外服务仅对已签合同确认。' * 80 +
                      ' Capacity | expansion remains a future plan, not current revenue.')
    desc['lines'][2] = quote
    desc['summary_claims'][0]['text'] = 'Management described contracted services; expansion remains a future plan.'
    request, body, receipt = wire('2', desc)
    context = validate_narrative_response(request, body, receipt)
    value = context.to_dict()
    summary = value['summary']['draft']['claims'][0]
    data = forecast_document()
    data['as_of_date'] = value['as_of_date']
    data['sources'][0]['capture']['snapshot_sha256'] = value['source_ref']['content_sha256']
    apply_hash_fixes(data)
    binding = {'span_id': summary['evidence_ids'][0], 'claim_id': 'independent_long_anchor',
               'parameter_id': PARAMETER, 'support_type': 'rationale_support'}
    updated, _ = consume(request, context, data, [choose(binding, summary)])
    claim = next(c for c in updated['evidence_claims'] if c['claim_id'] == binding['claim_id'])
    assert claim['excerpt'] == quote
    assert claim['narrative_summary_use']['entry']['context_evidence_ids']
    return updated, claim, quote


def proof_size(proof):
    return len(json.dumps(proof, ensure_ascii=False, allow_nan=False).encode('utf-8'))


def pad_proof_to(claim, target, chinese=False):
    proof = claim['narrative_summary_use']
    count = target - proof_size(proof)
    assert count > 0
    padding = ('界' * (count // 3) + 'x' * (count % 3)) if chinese else 'x' * count
    proof['summary_claim']['text'] += padding
    proof['entry']['summary_claim_sha256'] = canonical_sha256(proof['summary_claim'])
    assert proof_size(proof) == target


def test_grouped_long_quote_native_is_pure_and_keeps_qualifier():
    data, claim, quote = adopted()
    before = deepcopy(data)
    validate_document(data)
    validate_document(data, collector=Collector())
    assert data == before
    assert claim['excerpt'] == quote and len(quote) > 500
    assert quote.endswith('future plan, not current revenue.')
    assert any(s['raw_text'].startswith('[Analyst]') for s in claim['narrative_summary_use']['evidence_spans'])


@pytest.mark.parametrize('fake', [None, {}, [], True, 'proof'])
def test_present_fake_proof_never_waives_provenance(fake):
    data, claim, _ = adopted()
    claim['narrative_summary_use'] = fake
    with pytest.raises(ValueError, match='summary_provenance_schema'):
        validate_document(data)


@pytest.mark.parametrize('fault', ['quote_rehash', 'locator', 'remove_context_span',
                                 'remove_reading_context', 'context_list_erasure',
                                 'wrong_source', 'wrong_formula', 'no_backlink'])
def test_long_quote_negative_closure_cases(fault):
    data, claim, _ = adopted()
    proof = claim['narrative_summary_use']
    if fault == 'quote_rehash':
        claim['excerpt'] += ' Unsupported statement.'
        claim['excerpt_sha256'] = text_sha256(claim['excerpt'])
    elif fault == 'locator':
        claim['locator'] += '/wrong'
    elif fault == 'remove_context_span':
        omitted = proof['entry']['context_evidence_ids'][0]
        proof['evidence_spans'] = [s for s in proof['evidence_spans'] if s['span_id'] != omitted]
    elif fault == 'remove_reading_context':
        proof['reading_context'] = None
    elif fault == 'context_list_erasure':
        proof['summary_claim']['context_evidence_ids'] = []
        proof['entry']['context_evidence_ids'] = []
        proof['entry']['summary_claim_sha256'] = canonical_sha256(proof['summary_claim'])
    elif fault == 'wrong_source':
        proof['source_ref']['content_sha256'] = 'f' * 64
    elif fault == 'wrong_formula':
        proof['entry']['formula_refs'] = []
    else:
        next(p for p in data['parameters'] if p['parameter_id'] == PARAMETER)['claim_ids'].remove(claim['claim_id'])
    with pytest.raises(ValueError):
        validate_document(data)
    with pytest.raises(ValueError):
        validate_document(data, collector=Collector())


@pytest.mark.parametrize(('length', 'accepted'), [(9, False), (10, True), (500, True), (501, False)])
def test_legacy_short_excerpt_boundaries(length, accepted):
    data = forecast_document()
    claim = data['evidence_claims'][0]
    claim['excerpt'] = 'x' * length
    claim['excerpt_sha256'] = text_sha256(claim['excerpt'])
    assert 'narrative_summary_use' not in claim
    if accepted:
        validate_document(data)
    else:
        with pytest.raises(ValueError, match='10-500 characters'):
            validate_document(data)


@pytest.mark.parametrize(('length', 'accepted'), [(9, False), (10, True)])
def test_adopted_excerpt_minimum_remains_ten(length, accepted):
    data, _, _ = adopted('x' * length)
    if accepted:
        validate_document(data)
    else:
        with pytest.raises(ValueError, match='summary_provenance_excerpt_byte_bound'):
            validate_document(data)


def test_manual_claim_path_does_not_import_optional_summary_owner(monkeypatch):
    data = forecast_document()
    original_import = builtins.__import__

    def guarded_import(name, *args, **kwargs):
        if name == 'narrative_summary_provenance':
            raise AssertionError('manual evidence unnecessarily imports optional summary owner')
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, '__import__', guarded_import)
    validate_document(data)


@pytest.mark.parametrize(('target', 'chinese', 'accepted'), [
    (MAX_BYTES, False, True), (MAX_BYTES + 1, False, False),
    (MAX_BYTES, True, True), (MAX_BYTES + 1, True, False)])
def test_complete_proof_byte_boundary(target, chinese, accepted):
    data, claim, _ = adopted()
    pad_proof_to(claim, target, chinese)
    if accepted:
        validate_document(data)
    else:
        with pytest.raises(ValueError, match='summary_provenance_byte_bound'):
            validate_document(data)


def test_multibyte_excerpt_guard_counts_utf8_bytes():
    data, claim, _ = adopted()
    claim['excerpt'] = '界' * (MAX_BYTES // 3 + 1)
    claim['excerpt_sha256'] = text_sha256(claim['excerpt'])
    assert len(claim['excerpt']) < MAX_BYTES
    with pytest.raises(ValueError, match='summary_provenance_excerpt_byte_bound'):
        validate_document(data)


def test_long_quote_publication_report_snapshot_preserve_complete_proof():
    data, claim, quote = adopted()
    expected_claim = deepcopy(claim)
    result = run_forecast(deepcopy(data))
    validate_published_forecast(result, result['input_document'])
    report = render_markdown(result)
    snap = create_snapshot(deepcopy(data), 'independent-long-anchor')
    validate_snapshot(snap)
    containers = [result['evidence_claims'], result['input_document']['evidence_claims'],
                  snap['input_document']['evidence_claims'], snap['forecast_result']['evidence_claims']]
    for claims in containers:
        assert next(c for c in claims if c['claim_id'] == claim['claim_id']) == expected_claim
    assert _escape(quote) in report
    assert _escape(expected_claim['narrative_summary_use']['summary_claim']['text']) in report
    assert _escape(expected_claim['narrative_summary_use']['entry']['research_reason']) in report
    assert 'future plan, not current revenue.' in report


def test_fixed_real_eight_cards_validate_without_any_file_rewrite():
    raw = REAL_INPUT.read_bytes()
    assert len(raw) == 804624
    assert hashlib.sha256(raw).hexdigest() == '22e23a23b0827b969ec30a23c8910608127e06f86de1fde9554996d5ff34d1cc'
    data = json.loads(raw)
    frozen = deepcopy(data)
    validate_document(data)
    assert data == frozen
    adopted_claims = [c for c in data['evidence_claims'] if 'narrative_summary_use' in c]
    assert len(adopted_claims) == 8
    assert 519 in [len(c['excerpt']) for c in adopted_claims]
    assert REAL_INPUT.read_bytes() == raw
    record = {'input_path': str(REAL_INPUT), 'raw_bytes': len(raw),
              'raw_sha256': hashlib.sha256(raw).hexdigest(),
              'canonical_sha256': canonical_sha256(data), 'status': 'PASS', 'input_unchanged': True,
              'cards': [{'claim_id': c['claim_id'], 'excerpt_chars': len(c['excerpt']),
                         'excerpt_utf8_bytes': len(c['excerpt'].encode('utf-8')),
                         'excerpt_sha256': c['excerpt_sha256'],
                         'proof_bytes': proof_size(c['narrative_summary_use'])} for c in adopted_claims]}
    (OUTPUT / 'real-input-check.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def test_ci_selects_long_anchor_regression_exactly_once(monkeypatch):
    spec = importlib.util.spec_from_file_location('independent_rf_gate', RF / 'tools/pre_push_gate.py')
    gate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gate)
    target = 'tests/test_summary_long_excerpt.py'
    assert gate.SMOKE_TESTS.count(target) == 1
    calls = []
    monkeypatch.setattr(gate, '_run', lambda command, label, **kw: calls.append(command) or 0)
    assert gate.main([]) == 0
    commands = [cmd for cmd in calls if cmd[:3] == [sys.executable, '-m', 'pytest']]
    assert len(commands) == 1 and commands[0].count(target) == 1
