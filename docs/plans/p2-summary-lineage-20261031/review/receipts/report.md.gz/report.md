# 中山华利实业集团股份有限公司营收预测

- 信息截止日：2026-10-31
- 财年截止日：12-31
- 币种与单位：CNY million
- 基期营收：24,980.13
- 预测版本：CN-300979-M8-adoption-20261031-v1

## 核心营收结论

| 情景 | 终值营收 | CAGR | 营收增量 |
|---|---:|---:|---:|
| low | 22,484.12 | -10.0% | -2,496.01 |
| base | 25,376.99 | 1.6% | 396.87 |
| high | 27,243.13 | 9.1% | 2,263.00 |

## 未来收入主要驱动力

1. **Customer order mix and recognized sell-through** — Conditional continuation of sold-pair growth with flat realized footwear price; demand, delivery and customer conditions constrain revenue, not announced factories. （Base终年增量 396.87；占正向驱动 100.0%；证据 limited）

## 历史营收

| 年度 | 营收 | 口径 | 换算 | 来源ID |
|---:|---:|---|---|---|
| 2024 | 24,006.39 | 未声明 | — | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 |
| 2025 | 24,980.13 | 未声明 | — | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 |

### 口径可比性

- FY2024→FY2025：口径未声明或可比依据不足（basis not declared on the left observation）；沿用既有数值比较，不视为已核实口径；同比 4.1%。

### 基数采用

- 实际采用 FY2025 历史观测（24,980.13 CNY million，口径 未声明，来源 urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74）作为预测基数锚点；与报告总额参数一致（参数 reported_total = 24,980.13，容差 1e-06，差值 0.00）；未附原始值换算记录。

## 九维研究覆盖

- 进入模型：3；数据缺口：6；当前不重要：0。
- 本表用于防止研究漏项，不直接给CAGR或置信度加分。

| 维度 | 状态 | 结论 | 营收传导 | 参数ID | 来源ID | 理由 |
|---|---|---|---|---|---|---|
| company_foundation | modeled_driver | FY2025 total and footwear/other reconcile exactly; Sina raw values unit-verified against official filing. | Demand/order mix -> delivered footwear under capacity constraints -> contract-specific recognized revenue | reported_total | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | Do not interpret this integration case as complete current company research. |
| growth_curve | modeled_driver | Conditional sold pairs times flat FY2025 footwear realized price, separately flat other business; not a calibrated current forecast. | Demand/order mix -> delivered footwear under capacity constraints -> contract-specific recognized revenue | footwear_units_base_2026 | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | Do not interpret this integration case as complete current company research. |
| industry_market | data_gap | Bounded adoption case; current independent industry_market evidence remains insufficient. | Demand/order mix -> delivered footwear under capacity constraints -> contract-specific recognized revenue | — | — | Do not interpret this integration case as complete current company research. |
| competition | data_gap | Bounded adoption case; current independent competition evidence remains insufficient. | Demand/order mix -> delivered footwear under capacity constraints -> contract-specific recognized revenue | — | — | Do not interpret this integration case as complete current company research. |
| capacity | data_gap | Bounded adoption case; current independent capacity evidence remains insufficient. | Demand/order mix -> delivered footwear under capacity constraints -> contract-specific recognized revenue | — | — | Do not interpret this integration case as complete current company research. |
| technology | data_gap | Bounded adoption case; current independent technology evidence remains insufficient. | Demand/order mix -> delivered footwear under capacity constraints -> contract-specific recognized revenue | — | — | Do not interpret this integration case as complete current company research. |
| policy | data_gap | Bounded adoption case; current independent policy evidence remains insufficient. | Demand/order mix -> delivered footwear under capacity constraints -> contract-specific recognized revenue | — | — | Do not interpret this integration case as complete current company research. |
| customers | modeled_driver | FY2025 client/order divergence supports conditional volume mechanism; latest2026 customer evidence remains missing. | Demand/order mix -> delivered footwear under capacity constraints -> contract-specific recognized revenue | footwear_units_base_2026 | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | Do not interpret this integration case as complete current company research. |
| demand | data_gap | Bounded adoption case; current independent demand evidence remains insufficient. | Demand/order mix -> delivered footwear under capacity constraints -> contract-specific recognized revenue | — | — | Do not interpret this integration case as complete current company research. |

## 管理层沟通与营收目标覆盖

- 已检查官方沟通类别：1/6；重大/相关目标：0；已进入情景：0；独立基准比较：0；未建模：0。

| 沟通类别 | 状态 | 结论 | 目标ID | 来源ID |
|---|---|---|---|---|
| latest_annual_filing | checked | FY2025 annual filing actually acquired and read, including units/policy/strategy/risk. | — | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 |
| latest_results_release | incomplete | FY2025 annual source read; no exhaustive latest2026 communication search claimed. | — | — |
| latest_earnings_call | incomplete | FY2025 annual source read; no exhaustive latest2026 communication search claimed. | — | — |
| latest_investor_presentation | incomplete | FY2025 annual source read; no exhaustive latest2026 communication search claimed. | — | — |
| latest_strategy_communication | incomplete | FY2025 annual source read; no exhaustive latest2026 communication search claimed. | — | — |
| material_announcements_since_last_filing | incomplete | FY2025 annual source read; no exhaustive latest2026 communication search claimed. | — | — |

| 目标 | 强度 | 原始目标 | 来源期间 | 测量口径/模型期间 | 业务口径 | 处理 | 映射情景 | 模型兑现度 |
|---|---|---:|---|---|---|---|---|---|

## 年度情景路径

| 年度 | Low | Base | High | Base同比 |
|---:|---:|---:|---:|---:|
| 2026 | 22,484.12 | 25,376.99 | 27,243.13 | 1.6% |

## 三情景经营驱动

| 分部 | 情景 | 驱动 | 年度 | 参数ID | 数值 |
|---|---|---|---:|---|---:|
| Footwear | low | units | 2026 | footwear_units_low_2026 | 204,291,000.00 |
| Footwear | low | unit_revenue | 2026 | footwear_unit_revenue_low_2026 | 0.00010996115 |
| Footwear | low | timing_factor | 2026 | default | 1.00 |
| Footwear | low | other_revenue | 2026 | default | 0.00 |
| Footwear | base | units | 2026 | footwear_units_base_2026 | 230,599,141.00 |
| Footwear | base | unit_revenue | 2026 | footwear_unit_revenue_base_2026 | 0.00010996115 |
| Footwear | base | timing_factor | 2026 | default | 1.00 |
| Footwear | base | other_revenue | 2026 | default | 0.00 |
| Footwear | high | units | 2026 | footwear_units_high_2026 | 247,570,000.00 |
| Footwear | high | unit_revenue | 2026 | footwear_unit_revenue_high_2026 | 0.00010996115 |
| Footwear | high | timing_factor | 2026 | default | 1.00 |
| Footwear | high | other_revenue | 2026 | default | 0.00 |
| Other | low | revenue | 2026 | other_revenue_low_2026 | 20.04 |
| Other | base | revenue | 2026 | other_revenue_base_2026 | 20.04 |
| Other | high | revenue | 2026 | other_revenue_high_2026 | 20.04 |

## 分部驱动与收入确认

| 分部 | 模型 | 基期营收 | 确认时点 | 触发条件 | 列报 |
|---|---|---:|---|---|---|
| Footwear | unit_sales | 24,960.08 | point_in_time | Already recognized sales at contract-specific control transfer: FOB customs/loading; FCA designated carrier; DAT/DAP destination delivery. Not orders, factory construction, or undelivered output. | gross |
| Other | direct_revenue | 20.04 | point_in_time | Already recognized sales at contract-specific control transfer: FOB customs/loading; FCA designated carrier; DAT/DAP destination delivery. Not orders, factory construction, or undelivered output. | gross |

## Base情景增量归因

| 项目 | 终值营收增量 |
|---|---:|
| Footwear | 396.87 |
| Other | 0.00 |
| 公司级调整 | 0.00 |
| 合计 | 396.87 |

## 收入增长驱动树

### Customer order mix and recognized sell-through

- 结论：Conditional continuation of sold-pair growth with flat realized footwear price; demand, delivery and customer conditions constrain revenue, not announced factories.
- 因果链：Divergent old/new customer orders → Flexible production and qualified deliveries → Contract-specific control transfer → Recognized footwear revenue plus separately flat0.08% residual
- Base终年增量：396.87；正向增量占比：100.0%
- 归因分部：Footwear=100.0%, Other=100.0%
- 模型参数：footwear_units_base_2026, footwear_unit_revenue_base_2026, other_revenue_base_2026
- 持续性：uncertain；One-year conditional integration case, not calibrated structural growth; no independent reference-class or latest2026 communication claim.
- 领先指标：Recognized footwear revenue and actual sold pairs；New-client deliveries versus legacy-client declines
- 可证伪条件：FY2026 sold-pair growth materially deviates from conditional1.59% base；Price/mix/FX departs from flat2025 realized price；Orders are delayed or not recognized under contract control-transfer terms
- 反证检索：found；Actual annual report risk and legacy-client declines read; no independent2026 magnitude calibration. Residual other revenue held flat, so its allocated increment is zero.
- 证据状态：limited
- 支撑证据：
  - [company_disclosure/one_step] FY2025 new-client ramps and divergent orders support mechanism, not exact2026 volume.（Claim: claim_driver_orders；来源: urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74）
  - [company_risk/contrary] Weak end demand and international trade/tariff risks can break the assumed conversion.（Claim: claim_driver_risks；来源: urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74）

### 驱动归因对账

- 驱动归因的分部增量：396.87
- 分部增量合计：396.87
- 未归入经营驱动排名的公司级调整：0.00
- 与公司总增量差额：0.00

## 敏感性

未配置确定性敏感性测试。

## 预测置信度

- 等级：medium
- 分数：60.0/100
- 驱动证据覆盖率：100.0%

| 组成 | 得分 |
|---|---:|
| verified_claim_quality | 14.0 |
| verified_claim_coverage | 25.0 |
| source_freshness | 6.0 |
| revenue_weighted_explicit_models | 15.0 |
| historical_accuracy | 0.0 |
| revenue_weighted_sensitivity_coverage | 0.0 |

### 质量硬门

- base_reconciliation：通过
- recognition_contract：通过
- scenario_consistency：通过
- research_coverage：通过
- management_target_coverage：通过
- growth_driver_tree：通过

## 反证指标与数据缺口

### 反证指标
- 未提供。

### 数据缺口
- Current FY2026 latest results/communications and independent demand/reference-class calibration are not yet reviewed.
- Old2023 IR content time is May2023; current_verified_open proves2026 availability, never a new2026 capacity plan.
- Scenario rates and flat ASP are conditional assumptions; no confidence/calibration claim.
- industry_market: Bounded adoption case; current independent industry_market evidence remains insufficient.
- competition: Bounded adoption case; current independent competition evidence remains insufficient.
- capacity: Bounded adoption case; current independent capacity evidence remains insufficient.
- technology: Bounded adoption case; current independent technology evidence remains insufficient.
- policy: Bounded adoption case; current independent policy evidence remains insufficient.
- demand: Bounded adoption case; current independent demand evidence remains insufficient.
- management_communication:latest_results_release: incomplete
- management_communication:latest_earnings_call: incomplete
- management_communication:latest_investor_presentation: incomplete
- management_communication:latest_strategy_communication: incomplete
- management_communication:material_announcements_since_last_filing: incomplete

## 参数—证据claim映射

| 参数ID | 身份 | 数值 | 单位 | 期间 | 维度 | Claim ID | 来源ID | 支持类型 | 定位 | 短摘录 |
|---|---|---:|---|---|---|---|---|---|---|---|
| reported_total | reported_fact | 24,980.13 | CNY million | FY2025 | revenue | claim_reported_total | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | exact_value | PDF p8/16 or p16/20; yuan divided by1e6 | 营业收入（元）  24,980,125,148.09  24,006,393,622.27  4.06%  20,113,741,026.09 |
| footwear_base | reported_fact | 24,960.08 | CNY million | FY2025 | revenue | claim_footwear_base | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | exact_value | PDF p8/16 or p16/20; yuan divided by1e6 | 运动鞋  24,960,081,021.93  99.92%  23,958,685,422.52  99.80%  4.18%  其他业务  20,044,126.16  0.08%  47,708,199.75  0.20%  -57.99% |
| other_base | reported_fact | 20.04 | CNY million | FY2025 | revenue | claim_other_base | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | exact_value | PDF p8/16 or p16/20; yuan divided by1e6 | 运动鞋  24,960,081,021.93  99.92%  23,958,685,422.52  99.80%  4.18%  其他业务  20,044,126.16  0.08%  47,708,199.75  0.20%  -57.99% |
| footwear_units_low_2026 | analyst_assumption | 204,291,000.00 | pairs | FY2026 | quantity | claim_footwear_units_low_2026 | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | rationale_support | PDF p15/20 + p17/21 sold pairs1.59% growth in2025; p30/27-29 demand/trade risk; future scenarios explicitly conditional | 2025 年全年，公司销售运动鞋2.27 亿双，同比增长1.59%； 销售量  万双  22,699  22,343  1.59% 购、产品的交付均通过国际贸易进行。 地缘政治风险、主要进口国的经济环境发生重大变化或消费需求转弱、进出口国的 贸易政策、关税政策发生重大变化，将可能对公司业务的发展产生重要影响。 |
| footwear_unit_revenue_low_2026 | analyst_assumption | 0.00010996115 | CNY million per pair | FY2026 | revenue_per_unit | claim_footwear_unit_revenue_low_2026 | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | rationale_support | PDF p16/13-14,20 + p17/21; FY2025 footwear yuan /1e6 /22699wan pairs; flat future price is assumption | 单位：元 2025 年  2024 年 运动鞋  24,960,081,021.93  99.92%  23,958,685,422.52  99.80%  4.18%  其他业务  20,044,126.16  0.08%  47,708,199.75  0.20%  -57.99% 销售量  万双  22,699  22,343  1.59% |
| footwear_units_base_2026 | analyst_assumption | 230,599,141.00 | pairs | FY2026 | quantity | claim_footwear_units_base_2026 | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | rationale_support | PDF p15/20 + p17/21 sold pairs1.59% growth in2025; p30/27-29 demand/trade risk; future scenarios explicitly conditional | 2025 年全年，公司销售运动鞋2.27 亿双，同比增长1.59%； 销售量  万双  22,699  22,343  1.59% 购、产品的交付均通过国际贸易进行。 地缘政治风险、主要进口国的经济环境发生重大变化或消费需求转弱、进出口国的 贸易政策、关税政策发生重大变化，将可能对公司业务的发展产生重要影响。 |
| footwear_units_base_2026 | analyst_assumption | 230,599,141.00 | pairs | FY2026 | quantity | claim_m8_ir_order_direction | urn:company-wiki:source:sha256:d4cec6d382d1d26e441b240a914406ce66a8a304dc32ddbe0a283c540876c831 | rationale_support | loc:v1/page:1/paragraph:28 | A：目前部分运动品牌的库存比较高，同时由于国际政治、经济形势复杂，很多品牌基 |
| footwear_unit_revenue_base_2026 | analyst_assumption | 0.00010996115 | CNY million per pair | FY2026 | revenue_per_unit | claim_footwear_unit_revenue_base_2026 | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | rationale_support | PDF p16/13-14,20 + p17/21; FY2025 footwear yuan /1e6 /22699wan pairs; flat future price is assumption | 单位：元 2025 年  2024 年 运动鞋  24,960,081,021.93  99.92%  23,958,685,422.52  99.80%  4.18%  其他业务  20,044,126.16  0.08%  47,708,199.75  0.20%  -57.99% 销售量  万双  22,699  22,343  1.59% |
| footwear_units_high_2026 | analyst_assumption | 247,570,000.00 | pairs | FY2026 | quantity | claim_footwear_units_high_2026 | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | rationale_support | PDF p19/17-20; FY2025 nominal capacity24757wan pairs, not a2026 actual | 公司自有产能状况 本报告期  上年同期 总产能（万双）  24,757                                22,854 总产量（万双）   22,677    22,104 |
| footwear_unit_revenue_high_2026 | analyst_assumption | 0.00010996115 | CNY million per pair | FY2026 | revenue_per_unit | claim_footwear_unit_revenue_high_2026 | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | rationale_support | PDF p16/13-14,20 + p17/21; FY2025 footwear yuan /1e6 /22699wan pairs; flat future price is assumption | 单位：元 2025 年  2024 年 运动鞋  24,960,081,021.93  99.92%  23,958,685,422.52  99.80%  4.18%  其他业务  20,044,126.16  0.08%  47,708,199.75  0.20%  -57.99% 销售量  万双  22,699  22,343  1.59% |
| other_revenue_low_2026 | analyst_assumption | 20.04 | CNY million | FY2026 | revenue | claim_other_revenue_low_2026 | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | rationale_support | PDF p16/20: separately reported FY2025 residual other business; future flat assumption | 运动鞋  24,960,081,021.93  99.92%  23,958,685,422.52  99.80%  4.18%  其他业务  20,044,126.16  0.08%  47,708,199.75  0.20%  -57.99% |
| other_revenue_base_2026 | analyst_assumption | 20.04 | CNY million | FY2026 | revenue | claim_other_revenue_base_2026 | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | rationale_support | PDF p16/20: separately reported FY2025 residual other business; future flat assumption | 运动鞋  24,960,081,021.93  99.92%  23,958,685,422.52  99.80%  4.18%  其他业务  20,044,126.16  0.08%  47,708,199.75  0.20%  -57.99% |
| other_revenue_high_2026 | analyst_assumption | 20.04 | CNY million | FY2026 | revenue | claim_other_revenue_high_2026 | urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74 | rationale_support | PDF p16/20: separately reported FY2025 residual other business; future flat assumption | 运动鞋  24,960,081,021.93  99.92%  23,958,685,422.52  99.80%  4.18%  其他业务  20,044,126.16  0.08%  47,708,199.75  0.20%  -57.99% |

## 资料摘要的实际采用

### footwear_units_base_2026 / t3-source

- Artifact SHA：`ec1831a2fdf2952a9a80aba0c9e5db65c8bc581ea5c0a10d53d01ef2faba52d8`
- 原文 SHA：`d4cec6d382d1d26e441b240a914406ce66a8a304dc32ddbe0a283c540876c831`
- 来源质量：needs_review；摘要语义：not_evaluated。资料引用不表示投资结论通过。
- 采用理由（分析者）：May2023 IR says some customers decline, others grow, new customers EXPECTED to partly fill order gaps. Historical mechanism only, corroborated by FY2025 annual actual divergent orders/new client ramps; does not prove2026 volumes, full offset, current guidance or revenue recognition. Conditional1.59% base uses2025 observed volume growth as transparent assumption.
- 实际公式依赖：[{'segment': 'Footwear', 'scenario': 'base', 'model': 'unit_sales', 'driver': 'units', 'output': 'recognized_revenue'}]

摘要内容（保留原不确定性；事实短摘录仅为定位锚）：

> A：目前部分运动品牌的库存比较高，同时由于国际政治、经济形势复杂，很多品牌基 于对未来经济形势的不确定性，订单预测相对保守。 从目前的已经下达的订单及预告订 单情况看，部分品牌订单同比去年有下滑，部分品牌订单有增长，同时新客户的订单也 会弥补一些下滑客户的订单缺口。

| 分区 | Span ID | 原文定位 | 原文 |
|---|---|---|---|
| 上下文 | urn:company-wiki:evidence-span:sha256:48621bad8b303e7da33fb8ed4a739c22e77369d4d752a87ddf43f17db8d5b1f2 | loc:v1/page:1/paragraph:27 | Q：目前公司订单情况如何？ |
| 事实支持 | urn:company-wiki:evidence-span:sha256:79e9974f0826c3d697785012459446cce82d3905f63bbfa3e63b094d50441a4f | loc:v1/page:1/paragraph:28 | A：目前部分运动品牌的库存比较高，同时由于国际政治、经济形势复杂，很多品牌基 |
| 事实支持 | urn:company-wiki:evidence-span:sha256:cfde56d28b4a7f71c8ec2abb2e44ea10270e938fac655bd7884f85781d21166e | loc:v1/page:1/paragraph:29 | 于对未来经济形势的不确定性，订单预测相对保守。 |
| 事实支持 | urn:company-wiki:evidence-span:sha256:4170f879d11ea80105b8c87aad3d4e9cb7e90123c48bb2aac5f6fe217c1c3d8a | loc:v1/page:1/paragraph:30 | 从目前的已经下达的订单及预告订 |
| 事实支持 | urn:company-wiki:evidence-span:sha256:e47a4b536225b7796381279df16573dde61d08623c7500902c27904bca8e0f99 | loc:v1/page:1/paragraph:31 | 单情况看，部分品牌订单同比去年有下滑，部分品牌订单有增长，同时新客户的订单也 |
| 事实支持 | urn:company-wiki:evidence-span:sha256:494f0e2a911ba3dff38b392add46a92aff62ed99c7b852f4e56fe1e2dae97af5 | loc:v1/page:1/paragraph:32 | 会弥补一些下滑客户的订单缺口。 |

## 参数来源

| ID | 等级 | 类型 | 发布方 | 日期 | 定位 | 标题 |
|---|---:|---|---|---|---|---|
| [urn:company-wiki:source:sha256:15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74](https://www.cninfo.com.cn/new/disclosure/detail?stockCode=300979&announcementId=1225089943&announcementTime=2026-04-10%2000:00) | 1 | audited_filing | 中山华利实业集团股份有限公司 | 2026-04-10 | PDF p6,p8,p15-19,p30,p133 | 2025年年度报告 |
| urn:company-wiki:source:sha256:d4cec6d382d1d26e441b240a914406ce66a8a304dc32ddbe0a283c540876c831 | 2 | company_release | company-wiki | 未知 | 1 | 华利集团：300979华利集团调研活动信息20230519 |
