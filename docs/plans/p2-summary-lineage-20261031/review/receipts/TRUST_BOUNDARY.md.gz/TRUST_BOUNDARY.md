# 信任边界与验收范围

本工件是华利真实来源到native收入参数/公式的单年条件集成验收，不是完整公司RF-audit通过或可供投资决策的当前预测。

- 可由结构/哈希/独立重算证明：输入、来源捕获引用、完整摘要采用DTO、原文support/context、参数实际用途、三情景公式、正式结果与snapshot/registry绑定。
- 依赖宿主实际操作记录：FF/CWP下载、公开reader调用与字节定位回放确实发生；无独立可信宿主签名，不以unattested代称外部真实性已认证。
- 2023-05 IR只作历史机制/方向rationale，不是2026新订单、已完全抵消或新产能目标。current_verified_open不是发布日期，文件名不替代内容时间。
- FY2025收入API值与官方年报逐值核对；原API单位null不改，单位证明在年报人民币定义与营业收入(元)。Footwear与Other分开，万双换pairs，价采用CNY million/pair；不是USD或亿元误换。
- Low90%销量、Base重演2025的1.59%增速、High2025名义产能+flat inventory、单价flat均是显式条件假设，非管理2026指导或经样本外校准的概率边界。
- 最新2026结果/电话会/演示与独立需求、竞争等研究仍incomplete/gap；formal仅表示程序发布合同/重算通过，不表示这些研究缺口被关闭。
