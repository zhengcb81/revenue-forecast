# P2 v6 new-artifact delta — independent review

Review date: 2026-11-01. Decision: **PASS for bounded engineering adoption; 0 new blocking findings. Current company research remains OPEN.**

This is a same-node artifact delta to `review-v5-final.md`. It binds the new current Huali source artifact and actual v6 output, rather than reusing the old artifact's signature. RF HEAD was read as `535604fa468e8a69be44e073dc7e29eacde80cbc`; all six production module hashes exactly match the frozen final v5 review. No implementation, package or full-domain re-audit is implied.

## Exact new source and persisted use

| Identity | Independently checked value |
|---|---|
| New CWP artifact body | `a466262de5251f0b4e2619eb88f1ba90e8188f5070bb1ea9881a7d5be08b3a45` — 243,043 bytes |
| Actual original IR source | `d4cec6d382d1d26e441b240a914406ce66a8a304dc32ddbe0a283c540876c831` |
| Selected summary | `t3-source`, SHA `29df07901b23643bfd748cd0daef1c3b082c8797699eedbfddb8a644b3faefd6` |
| Actual adopted parameter | `footwear_units_base_2026` |
| Actual formula target | `Footwear / base / unit_sales / units → recognized_revenue` |
| Information date/version | `2026-11-01` / `CN-300979-M8-adoption-20261101-v6` |

The prepared capsule, its decompressed body, the current source run's recorded output digest, v6 reader request/receipt, consumption receipt, and per-claim native provenance all agree on the **new** artifact. The old `ec1831...` digest is absent from v6 input. The selected t3 text happens to be identical to the previous source meaning, but this does not substitute the prior artifact for the current one.

The full t3 claim, exact five support spans (p1/28–32), separate question context (p1/27), source-owned citation group, research reason, and real formula targets persist identically in v6 input, forecast evidence/embedded input and snapshot. Each persisted span was compared with this new artifact's actual span, not just with the sidecar. The report displays all original text/locators, the new artifact/source SHA, nonzero unit price with its unit, and the explicit analyst use reason.

The current source run records 15 summary claims/cards and charged usage 3,630 tokens / 660 micro-USD. This is read evidence of the existing P1 run, not a new call by this reviewer and not an independently verified provider invoice. P2 v6 itself records zero new POSTs and downloads.

## Independent checks and formal identities

`v6-delta.py` uses only Python's standard library. **All 45 checks pass**, with details, exact code/file hashes and decimal arithmetic in `v6-delta.json`. It makes no author-runtime, test, parser, model, download or network call.

| Formal anchor | SHA-256 |
|---|---|
| Canonical input | `11becbb72eec6c8d2a64d985a44bc7486e558286b8da279a891aa31558b2f8e8` |
| Published result | `d96a7c01add0b2a7d4b88607e7da103b9fee18e00861ed1dbc5524ffd0d7acdb` |
| Snapshot ID | `df5be201383c455e1343f18a6b6b5bb04adb67fd7c3c2ad997a2ac34913c6b46` |

Publication receipt, payload/input/result hashes, snapshot identity and full-result digest, and all three isolated registry chain entries independently match. Formal mode remains **unattested**. This establishes local mechanical binding, not a trusted external signature or an economically accepted forecast. The v6 temporary root is absent and its cleanup record says removed. Locator replay is recorded; no claim of zero parsing for that actual public-reader replay is made.

Every parameter value and all three consolidated scenario objects are exactly equal to the previously verified v5 case. Independent decimal recomputation again matches within less than `3e-12 CNY million`:

| Case | Conditional sold pairs | Company revenue, CNY million |
|---|---:|---:|
| Low | 204,291,000 | 22,484.117045896997 |
| Base | 230,599,141 | 25,376.990436338685 |
| High | 247,570,000 | 27,243.125577321767 |

The base parameter is used by the actual native unit-sales formula. Footwear-only revenue per sold pair is positive `0.00010996114816480902 CNY million/pair`; Other remains separate and flat. The report retains a nonzero price display and `CNY million per pair` unit.

## Baseline reuse without restoring deleted bulk materials

The 62 retained `selected-native-basis-spans.json.gz` records have distinct locators and valid canonical output/span hashes, all linked to official annual source SHA `15eb6c7669af7d05b341ec0f42b47c1da469776e56d299addb18ca53511a4c74`. Their currency definition, annual revenue, footwear/Other split, sold-pair and nominal-capacity anchors are present. Native annual-source capture and historical values equal v5, and every adopted annual original excerpt/hash equals the prior verified v5 evidence.

The small retained Sina JSON cache still matches its raw manifest digest. Its 2024/2025 amounts remain exact, provider unit/scale remain null, and the stored reuse records zero HTTP. Official yuan/annual-period evidence supplies the conversion to CNY million; no provider unit is invented.

The earlier raw/whole-document source verification remains the baseline authority from `review-v3.md`; this delta checks retained evidence and consistency with that audited baseline, not a fresh verification of deleted PDF bytes. The annual compressed original and full normalization remain absent. No deleted original, normalization or backup was restored, downloaded or parsed by this review.

## Temporal and research limits remain open

The source is still the May 2023 IR content. Unknown publication date and fiscal year/period remain unknown; `current_verified_open` now establishes availability by **2026-11-01**, not a newly published 2026 development. The reason preserves conservative forecasts, divergent old/new customer orders and expected partial gap filling. It does not assert guaranteed complete offset, current orders or realized 2026 capacity. Uncertain modality, `needs_review`, partial selection and unevaluated summary semantics remain intact.

Low 90% sold pairs, Base repeating the disclosed 2025 rounded 1.59% growth, High assuming sales at 2025 nominal capacity with flat inventory, and flat realized price remain conditional analyst assumptions. They are neither calibrated probabilities nor management 2026 guidance.

The report and native inputs continue to retain five incomplete communication categories and six research-dimension gaps. Latest 2026 communications and independent demand/competition/reference-class work are not signed complete. This PASS applies only to the source-to-native-parameter/formula/report/snapshot engineering chain for v6; it does not close P1 overall, P3, full-company RF-audit, or economic research.
