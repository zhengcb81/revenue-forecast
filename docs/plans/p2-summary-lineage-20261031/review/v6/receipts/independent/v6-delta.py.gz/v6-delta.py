"""Independent stdlib-only checks of persisted v6 data; no author runtime execution."""
from __future__ import annotations

from copy import deepcopy
from decimal import Decimal, getcontext
from pathlib import Path
import gzip
import hashlib
import json
import sys

getcontext().prec = 50
REVIEW = Path(__file__).resolve().parent
CWP = REVIEW.parents[2]
TASK = CWP / ".planning/mainline-closeout-20261031"
RF = CWP.parent / "revenue-forecast"
OUT = RF / ".planning/m8-native-adoption-20261031/v6"
CODE = RF


def sha(body):
    return hashlib.sha256(body).hexdigest()


def canonical(value):
    return sha(json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(",", ":")).encode("utf-8"))


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    checks = []

    def check(name, success, **facts):
        checks.append({"name": name, "pass": bool(success), **facts})

    i = load(OUT / "input.json")
    f = load(OUT / "forecast.json")
    snapshot = load(OUT / "snapshot.json")
    receipt = load(OUT / "consumption-receipt.json")
    request = load(OUT / "read-request.json")
    report = (OUT / "report.md").read_text(encoding="utf-8")
    claims = {c["claim_id"]: c for c in i["evidence_claims"]}
    parameters = {p["parameter_id"]: p for p in i["parameters"]}
    native_claim = claims["claim_m8_ir_order_direction"]
    proof = native_claim["narrative_summary_use"]
    entry = proof["entry"]
    caps = TASK / "p1-huali-live-v3/materials"
    capsule = json.loads(gzip.decompress(next(caps.glob("*.prepared.capsule.json.gz")).read_bytes()))
    body = gzip.decompress((caps / capsule["payload"]["file"]).read_bytes())
    bundle = json.loads(body)
    t3 = next(c for c in bundle["summary"]["draft"]["claims"] if c["claim_id"] == "t3-source")
    check("exact_cwp_bundle", sha(body) == proof["narrative_ref"]["artifact_sha256"]
          == "a466262de5251f0b4e2619eb88f1ba90e8188f5070bb1ea9881a7d5be08b3a45")
    check("summary_exact_cwp_claim", proof["summary_claim"] == t3
          and entry["summary_claim_sha256"] == canonical(t3))
    check("proof_entry_exact_consumption_receipt", entry == receipt["summary_use"]["entries"][0])
    check("artifact_ref_exact_reader_request_receipt", proof["narrative_ref"] == request["narrative_ref"]
          == receipt["narrative_ref"] == proof["read_receipt"]["narrative_ref"])
    wanted = set(t3["evidence_ids"] + t3["context_evidence_ids"])
    original = {s["span_id"]: s for s in bundle["evidence_spans"]}
    persisted = {s["span_id"]: s for s in proof["evidence_spans"]}
    check("all_original_support_and_context_spans_exact", set(persisted) == wanted
          and all(persisted[sid] == original[sid] for sid in wanted),
          support=len(t3["evidence_ids"]), context=len(t3["context_evidence_ids"]))
    check("full_continuous_answer", "\n".join(persisted[sid]["raw_text"] for sid in t3["evidence_ids"])
          == t3["text"] and "会弥补一些" in t3["text"])
    check("original_reading_group_exact", proof["reading_context"]["groups"] == [g for g in bundle["reading_context"]["groups"]
          if g["group_id"] == entry["citation"]["group_id"]])
    check("support_context_partition_preserved", entry["support_evidence_ids"] == t3["evidence_ids"]
          and entry["context_evidence_ids"] == t3["context_evidence_ids"]
          and not set(entry["support_evidence_ids"]).intersection(entry["context_evidence_ids"]))
    check("actual_native_claim_reference", native_claim["claim_id"] in parameters[entry["parameter_id"]]["claim_ids"]
          and native_claim["target_id"] == entry["parameter_id"] == "footwear_units_base_2026"
          and native_claim["source_id"] in parameters[entry["parameter_id"]]["source_ids"])
    check("real_formula_dependency", entry["formula_refs"] == [{"segment": "Footwear", "scenario": "base",
          "model": "unit_sales", "driver": "units", "output": "recognized_revenue"}]
          and i["segments"][0]["scenarios"]["base"]["driver_parameter_ids"]["units"] == [entry["parameter_id"]])
    check("unreviewed_uncertain_qualities_retained", t3["modality"] == "uncertain" and t3["needs_review"]
          and proof["quality_status"] == proof["draft_status"] == "needs_review"
          and proof["semantic_status"] is None and proof["subfact_coverage_status"] is None
          and proof["read_receipt"]["selection_status"] == "partial")
    manifest = proof["read_receipt"]["manifest"]
    check("unknown_publication_and_fiscal_time_retained", manifest["published_date"] is None
          and manifest["fiscal_year"] is None and manifest["fiscal_period"] is None
          and i["sources"][1]["published_date"] is None
          and proof["read_receipt"]["availability_evidence"]["basis"] == "current_verified_open")
    check("research_reason_and_source_time_reported", entry["research_reason"] in report
          and "May2023" in entry["research_reason"] and "EXPECTED to partly fill" in entry["research_reason"]
          and "Old2023 IR content time is May2023" in report)
    check("all_support_context_text_and_locators_in_report", all(
          s["raw_text"].replace("\n", " ") in report and s["locator"] in report and s["span_id"] in report
          for s in proof["evidence_spans"]))
    check("summary_identity_in_report", proof["narrative_ref"]["artifact_sha256"] in report
          and proof["source_ref"]["content_sha256"] in report and t3["claim_id"] in report)
    check("native_and_result_and_snapshot_freeze_identical_inputs", i == f["input_document"] == snapshot["input_document"]
          and f == snapshot["forecast_result"] and f["evidence_claims"] == i["evidence_claims"])
    input_hash = canonical(i)
    check("input_hash_freezes_full_proof", input_hash == f["input_sha256"] == snapshot["input_sha256"], sha256=input_hash)
    edited = deepcopy(i)
    next(c for c in edited["evidence_claims"] if c["claim_id"] == native_claim["claim_id"])["narrative_summary_use"]["entry"]["research_reason"] += " altered"
    check("reason_edit_changes_native_hash", canonical(edited) != input_hash)
    pub = f["publication_receipt"]
    check("formal_publication_hashes", canonical({k: v for k, v in f.items() if k != "result_sha256"}) == f["result_sha256"]
          and canonical({k: v for k, v in f.items() if k not in {"result_sha256", "publication_receipt"}}) == pub["validated_payload_sha256"]
          and canonical({k: v for k, v in pub.items() if k != "receipt_sha256"}) == pub["receipt_sha256"]
          and pub["formal_output_mode"] == "formal" and pub["attestation_status"] == "unattested")
    identity = {k: v for k, v in snapshot.items() if k not in {"snapshot_id", "input_document", "forecast_result"}}
    check("snapshot_hashes", canonical(identity) == snapshot["snapshot_id"]
          and canonical(f) == snapshot["forecast_result_sha256"], snapshot_id=snapshot["snapshot_id"])
    registry = [json.loads(x) for x in (OUT / "publication-registry.jsonl").read_text(encoding="utf-8").splitlines()]
    previous = None
    valid_chain = True
    for row in registry:
        valid_chain &= canonical({k: v for k, v in row.items() if k != "line_sha256"}) == row["line_sha256"]
        valid_chain &= row["prev_line_sha256"] == previous and row["input_sha256"] == input_hash
        valid_chain &= row["receipt_sha256"] == canonical(pub)
        previous = row["line_sha256"]
    check("isolated_registry_chain", valid_chain and len(registry) == 3
          and [r["artifact_type"] for r in registry] == ["forecast", "forecast", "snapshot"]
          and all(r["result_sha256"] == f["result_sha256"] for r in registry[:2])
          and registry[-1]["artifact_id"] == snapshot["snapshot_id"]
          and registry[-1]["result_sha256"] == canonical(f))
    volume_claim = claims["claim_footwear_units_base_2026"]
    capacity_claim = claims["claim_footwear_units_high_2026"]
    price_claim = claims["claim_footwear_unit_revenue_base_2026"]
    check("sold_pair_history_anchor_in_formal_claim", "22,699" in volume_claim["excerpt"]
          and "万双" in volume_claim["excerpt"] and "1.59%" in volume_claim["excerpt"]
          and "2025" in volume_claim["excerpt"] and "p17/21" in volume_claim["locator"])
    check("capacity_history_anchor_in_formal_claim", "24,757" in capacity_claim["excerpt"]
          and "总产能（万双）" in capacity_claim["excerpt"] and "FY2025" in capacity_claim["locator"]
          and "not a2026 actual" in capacity_claim["locator"])
    check("footwear_only_price_anchor_in_formal_claim", "单位：元" in price_claim["excerpt"]
          and "24,960,081,021.93" in price_claim["excerpt"] and "22,699" in price_claim["excerpt"]
          and "/1e6 /22699wan pairs" in price_claim["locator"])
    footwear = Decimal("24960081021.93") / 1000000
    other = Decimal("20044126.16") / 1000000
    asp = footwear / Decimal(226990000)
    math_rows = []
    for case, units in {"low": Decimal(204291000), "base": Decimal(230599141), "high": Decimal(247570000)}.items():
        expected = units * asp + other
        observed = Decimal(str(f["consolidated_forecast"][case]["terminal_revenue"]))
        check("independent_formula_" + case, abs(observed - expected) < Decimal("1e-8")
              and Decimal(str(parameters[f"footwear_units_{case}_2026"]["value"])) == units)
        math_rows.append({"case": case, "units": str(units), "expected_million": str(expected),
                          "observed_million": str(observed), "difference": str(observed - expected)})
    check("unit_price_nonzero_and_unit_displayed", "0.00010996115 | CNY million per pair" in report
          and "| 数值 | 单位 |" in report)
    check("all_future_values_explicit_assumptions", all(p["kind"] == "analyst_assumption" for p in i["parameters"]
          if p["period"] == "FY2026") and f["scenario_probabilities"] is None)
    check("company_research_gaps_preserved", sum(r["status"] == "incomplete" for r in i["management_communication_coverage"]) == 5
          and sum(r["status"] == "data_gap" for r in i["research_coverage"]) == 6
          and load(OUT / "receipt.json")["company_research_complete"] is False)
    cleanup = load(OUT / "cleanup.json")
    check("temp_cleanup", cleanup["removed"] is True and not Path(cleanup["temporary_root"]).exists())
    check("zero_new_model_download_record", load(OUT / "receipt.json")["new_POST"] == 0
          and load(OUT / "receipt.json")["new_downloads"] == 0)
    code_files = ["scripts/narrative_summary_provenance.py", "scripts/narrative_summary_usage.py", "scripts/source_narrative_context.py",
                  "scripts/company_wiki_narrative_contracts.py", "scripts/contracts/document.py",
                  "scripts/revenue_report.py", "tests/test_summary_publication_lineage.py"]
    old_dir = OUT.parent / "v5"
    old_input = load(old_dir / "input.json")
    old_forecast = load(old_dir / "forecast.json")
    old_claims = {c["claim_id"]: c for c in old_input["evidence_claims"]}
    old_probe = load(REVIEW / "probe-v5.json")
    check("all_parameter_values_equal_previous_verified_v5", [(p["parameter_id"], p["value"]) for p in i["parameters"]]
          == [(p["parameter_id"], p["value"]) for p in old_input["parameters"]])
    check("all_three_scenario_outputs_equal_v5", f["consolidated_forecast"] == old_forecast["consolidated_forecast"])
    check("history_and_annual_source_capture_equal_v5", i["historical_revenue"] == old_input["historical_revenue"]
          and i["sources"][0] == old_input["sources"][0])
    annual_claims = [c for c in i["evidence_claims"] if c["source_id"] == i["sources"][0]["source_id"]]
    check("annual_original_excerpts_equal_verified_v5", all(c["excerpt"] == old_claims[c["claim_id"]]["excerpt"]
          and c["excerpt_sha256"] == old_claims[c["claim_id"]]["excerpt_sha256"]
          for c in annual_claims))
    check("new_artifact_not_old_artifact_reused", proof["narrative_ref"]["artifact_sha256"]
          != next(c for c in old_input["evidence_claims"] if c["claim_id"] == native_claim["claim_id"])["narrative_summary_use"]["narrative_ref"]["artifact_sha256"]
          and "ec1831a2fdf2952a9a80aba0c9e5db65c8bc581ea5c0a10d53d01ef2faba52d8" not in json.dumps(i))
    check("unique_forecast_version_and_current_operation_date", i["forecast_version"] == "CN-300979-M8-adoption-20261101-v6"
          and i["as_of_date"] == proof["read_receipt"]["as_of_date"] == "2026-11-01"
          and proof["read_receipt"]["availability_evidence"]["available_by"] == "2026-11-01")
    annual_dir = TASK / "p2-annual-preparation-v4"
    selected_path = annual_dir / "selected-native-basis-spans.json.gz"
    selected_body = gzip.decompress(selected_path.read_bytes())
    selected = json.loads(selected_body)
    selected_by_loc = {span["locator"]: span for span in selected}
    selected_valid = True
    for span in selected:
        output = canonical({"raw_text": span["raw_text"], "structured_value": span["structured_value"]})
        sid = "urn:company-wiki:evidence-span:sha256:" + canonical({"source_id": span["source_id"], "locator": span["locator"], "output_sha256": output})
        selected_valid &= span["output_sha256"] == output and span["span_id"] == sid
        selected_valid &= span["source_id"] == i["sources"][0]["source_id"] and span["parse_status"] == "parsed"
    check("retained_62_basis_spans_locally_intact", len(selected) == len(selected_by_loc) == 62 and selected_valid,
          compressed_sha256=sha(selected_path.read_bytes()), expanded_sha256=sha(selected_body))
    check("retained_currency_revenue_and_operating_anchors", "人民币元" in selected_by_loc["loc:v1/page:6/paragraph:16"]["raw_text"]
          and "营业收入（元）" in selected_by_loc["loc:v1/page:8/paragraph:16"]["raw_text"]
          and "24,980,125,148.09" in selected_by_loc["loc:v1/page:8/paragraph:16"]["raw_text"]
          and "24,006,393,622.27" in selected_by_loc["loc:v1/page:8/paragraph:16"]["raw_text"]
          and "24,960,081,021.93" in selected_by_loc["loc:v1/page:16/paragraph:20"]["raw_text"]
          and "20,044,126.16" in selected_by_loc["loc:v1/page:16/paragraph:20"]["raw_text"]
          and "22,699" in selected_by_loc["loc:v1/page:17/paragraph:21"]["raw_text"]
          and "24,757" in selected_by_loc["loc:v1/page:19/paragraph:19"]["raw_text"])
    check("deleted_annual_bulk_files_not_restored", not (annual_dir / "original-0.pdf.gz").exists()
          and not (annual_dir / "normalized-spans.json.gz").exists())
    financial_dir = TASK / "p2-financial-preparation-v1"
    api = load(financial_dir / "fetch.stdout.json")
    cached = load(financial_dir / "reuse.stdout.json")
    financial_original = gzip.decompress((financial_dir / "original-0.json.gz").read_bytes())
    check("small_financial_cache_raw_hash_unchanged", sha(financial_original) == load(financial_dir / "original-0.manifest.json")["content_sha256"])
    amounts = {int(r["period_end"][:4]): next(x for x in r["rows"] if x["provider_field"] == "BIZINCO") for r in api["statements"][0]["reports"]}
    check("provider_unit_unknown_and_known_annual_amounts_retained", set(amounts) == {2024, 2025}
          and all(x["unit"] is None and x["scale"] is None for x in amounts.values())
          and Decimal(amounts[2024]["value_decimal"]) == Decimal("24006393622.27")
          and Decimal(amounts[2025]["value_decimal"]) == Decimal("24980125148.09")
          and cached["usage"]["http_requests"] == 0)
    production_hashes = {name: sha((CODE / name).read_bytes()) for name in code_files if name.startswith("scripts/")}
    check("six_production_modules_match_frozen_review", all(digest == old_probe["code_sha256_at_probe"][name]
          for name, digest in production_hashes.items()), rf_head_observed="535604fa468e8a69be44e073dc7e29eacde80cbc")
    native_usage = load(TASK / "p1-huali-live-v3/phaseC-090-670ced72c918.native-usage.json")
    check("new_prepared_artifact_matches_recorded_current_source_output", len(native_usage) == 1
          and native_usage[0]["output_sha256"] == sha(body)
          and native_usage[0]["charged_tokens"] == 3630 and native_usage[0]["charged_micro_usd"] == 660
          and len(bundle["summary"]["draft"]["claims"]) == 15)
    observations = {"schema_version": "independent-p2-v6-delta/1", "checks_pass": all(c["pass"] for c in checks),
                    "checks": checks, "math": math_rows, "network_calls": 0, "model_calls": 0,
                    "parser_calls": 0, "author_runtime_calls": 0,
                    "code_sha256_at_probe": {name: sha((CODE / name).read_bytes()) for name in code_files},
                    "artifacts_file_sha256": {name: sha((OUT / name).read_bytes()) for name in
                        ["input.json", "forecast.json", "snapshot.json", "report.md", "consumption-receipt.json", "publication-registry.jsonl"]}}
    (REVIEW / "v6-delta.json").write_text(json.dumps(observations, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8")
    print(json.dumps({"checks": len(checks), "all_pass": observations["checks_pass"],
                      "failed": [c["name"] for c in checks if not c["pass"]],
                      "input_sha256": input_hash, "snapshot_id": snapshot["snapshot_id"], "math": math_rows},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
