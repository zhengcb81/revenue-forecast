# DU6-RF-TARGET-MEASURES 独立验收与 ROOT 集成修复

日期：2026-10-16。作者 HEAD `86ca29411fbed1eaf2958b2eff579395f7d151a7`；源码基线 `5122107bbc86c3d1e79886b372700c05d19bb349`，种子 `75a7fb0cd5b2536680306d56ca89b2eebdd05770`。

## 结论

作者主体实现正确且集中回归通过；不能直接宣称所有新 builder 路径均可使用。独立控例确认三个 P2 类问题，已按 ROOT 授权仅在 `revenue-forecast-du67-integration` 修复两源码及新增六项测试，作者树保持干净、12 个交接 SHA 全匹配。待 ROOT 在合流节点排队执行最终集中回归/提交/推送/安装同步。本报告不代替全项目验收。

## 发现与修复

1. **P2：typed builder 仍先执行 legacy 年化分支。** 合法 `quarterly_revenue_level + quarterly_period` 被拒为缺乏 annual conversion；同时 typed spec 又禁止 conversion，因此原生季度公开构建路径不可用。ROOT 只将真实 native quarter 从 legacy annual conversion 分支分离，后续既有 quarter ancestry、期间/币种/尺度/参数验证全部保留；不做乘 4。独立合成公司含两个真实分部季度桥，手算 low/base/high = 107240/109600/111960，公开 CLI 和正式验证均一致。
2. **P2：typed builder 与 validator 对未建模目标语义不一致。** 默认/显式 `unmodeled_data_gap`、`out_of_horizon` 仍填 point comparison_value、notes.comparable=true，被本仓 typed validator 拒；未建模外币目标还被强制无证据 FX 归一化。ROOT 在 target_measurement 中提供一个 `is_modeled_comparison`，builder/validator/comparator共用。未建模保留 raw、不填 comparison_value、不做 FX、不虚构 numerical scenario mapping。另修 typed numeric_range claim 缺 unit/period：只给新 typed range补原始声明字段，不动旧缺省 builder shape。
3. **P2：旧正金额归一化乘除次序发生变化。** 1.1 million → 亿元，旧 `1.1*(1e6/1e8)` = `0.011000000000000001`，作者 `1.1*1e6/1e8` = `0.011`；在旧阈值严格相等时 greater_than 会由 false 翻 true。ROOT 恢复先算共享 factor 再乘原量；仍只有 DU5 Currency×Scale 一个金额词汇 owner，不恢复私有表。

三个问题已各有真实 RED；没有改旧 expected/旧测试/golden、费用上限或身份门禁。

## 独立验证

- 作者卡列 9 个测试文件：**193 passed + 119 subtests passed**（pytest显示73.62s；外层过程121.902s，宿主并发慢）。不是只引用作者记录。
- 作者 5 份已提交合成模型：每份真实 CLI `--validate-only`、正式 JSON/Markdown 各一次，**10 次 exit 0**。未运行作者 c_node_cli_run.py，因为它会重写作者夹具。
- 新手算点值 -0.25、0 及跨零 [-0.125,0.0625]：13 项独立二进制精确控例通过。
- ROOT 初始 **5 RED**；后续外币未建模共因补充 RED 保留；修复后的 **6 PASS /1.99s**，全部通过真实 formal→validate_published_forecast。
- ROOT 三份新模型公开 CLI（公司季度桥、默认未建模负增长、未建模外币）：**6 次 exit 0**，有独立手算断言，实际脚本/argv/输出见 `root-cli.json`。
- 定点 Ruff 两源码+新增测试通过。最后仅整理新测试格式和 E402 说明，AST 与六项 GREEN 时模板相同；最终集中回归交 ROOT 顺序运行，避免多个大套件挤占宿主。

## 失败记录与隔离

初轮 ROOT GREEN 暴露的是测试脚手架错误：Segment A 的季度夹具交给默认 company scope 的 builder，被原生 ancestry 正确拒绝；draft 输出送 formal validator，也被正确拒绝。已改为公司两分部实际季度桥和真实 formal 调用，未放松生产验证。fixture finalizer 会重建 evidence_claims，增加参数时须先保存目标原始证据再合并；StopIteration 失败记录也保留。

首次验收运行完成后清理遇 Windows 只读 publication-registry 测试夹具，导致最终汇总 receipt 未落盘；**不把这个进程 exit 1 当成测试失败，也不冒称原始全量 mtime 快照已留存**。全部 stdout/stderr 和 5 个摘要输出已保存。随后仅对精确自建 Temp 内文件解除只读并成功移除，见 cleanup-recovery.json。作者最终 Git clean，12 个源码/夹具/参考 SHA 均与交接一致。ROOT CLI 的来源哈希和三个默认 registry 存在性/SHA/mtime 前后完整一致；自建各 Temp 均清理。第一轮临时无 basetemp RED 仅创建空 pytest fixture 目录，另行精确移除空目录，未递归触碰其他 pytest 目录。

CodeGraph 已按用户授权初始化：310 个实际文件、6793 节点/6483 边；9895 个稀疏树不存在路径读取失败，未声称全仓索引完整。目标三入口结构查询成功。索引为本地忽略文件，无源码变化。

## 保留限制 / ROOT 待办

- 未跑真实公司/真实供应商、未付费、未读取密钥、未网络采集、未写安装副本。
- 最终两源码修复后的原193集中回归由 ROOT 排队执行；本线停止新增可选测试。
- 原 non-typed 与 typed approximately 历史绝对容差口径差异仍保留；当前卡不改 revenue_report 独立输出验证。
- operator×双端区间只有 approximately 语义明确；其余保持具名拒绝/保留 gap，不猜中点。
- references/money-unit-conversion.md 缺新增 scale 拼写，作者白名单外未改，ROOT可补最小文档。
- no claim about real forecast economics or all PWF completion；没有 Git 写、安装或推送。
